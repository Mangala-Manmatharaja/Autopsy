# Content Viewer Modules

Content viewer modules are located in the lower right of Autopsy and in other panels (such as timeline). They allow the user to view or analyze a specific file in different ways. 


