- __Known Issue:__ This module will cause Autopsy to lose its Tools menu (April 2020).

- __Description:__ Adds tagged evidence into structured and styled tables automatically and directly inside a forensic expert witness report, whilst coming with three pre-existing forensic expert witness report templates to choose from. 
- __Author:__ Chris Wipat
- __Minimum Autopsy version:__ : 3.0.7
- __Source Code:__ https://github.com/chriswipat/forensic_expert_witness_report_module
- __Release Download:__ https://github.com/chriswipat/forensic_expert_witness_report_module/releases/download/v1.0/ForensicExpertWitnessReport.nbm
- __License:__ GNU General Public License Version 3
- __Installation Instructions:__ https://github.com/chriswipat/forensic_expert_witness_report_module/blob/master/README.md
