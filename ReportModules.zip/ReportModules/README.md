# Report Modules

Report modules are typically run at the end of an investigation to produce an output report.  The extension point is also used as a place to manually start analysis techniques.

