- __Known Issues:__ This module does not work with the latest versions of Autopsy (April 2020 - https://sleuthkit.discourse.group/t/copy-move-module/1026)

- __Description:__ A module package containing a File Ingest Module and its corresponding Data Content Viewer. Allows the user to identify Copy-Move forgeries within images in the datasource. Please read the readme before using the package.
- __Author:__ Tobias Maushammer
- __Minimum Autopsy version:__ 4.1.0
- __Source Code:__ https://github.com/LoWang123/CopyMoveModulePackage
- __License:__ The MIT License(MIT)
