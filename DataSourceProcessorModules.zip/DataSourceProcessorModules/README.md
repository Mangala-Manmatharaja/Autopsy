# Data Source Processor Modules

Data source processor modules are used to add data sources to a case.  They are responsible for parsing input data and populating the database with files (or other items) so that ingest modules and other modules can analyze them.


